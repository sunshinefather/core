# core
1.更新spring 到3.2.5.RELEASE
