/**
 * 
 */
package com.palmlink.core.database.ibatis.mapper;

/**
 * @author Shihai.Fu
 *
 */
public interface SqlMapper {

}
