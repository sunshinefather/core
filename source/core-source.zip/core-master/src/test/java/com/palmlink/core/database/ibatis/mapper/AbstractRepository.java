/**
 * 
 */
package com.palmlink.core.database.ibatis.mapper;

/**
 * @author Shihai.Fu
 *
 */
public class AbstractRepository<T extends SqlMapper> {

    protected T mapper;
    
}
