package com.palmlink.core;

import com.palmlink.core.platform.DefaultWebConfig;
import org.springframework.context.annotation.Configuration;

/**
 * @author Shihai.Fu
 */
@Configuration
public class TestWebConfig extends DefaultWebConfig {
}
