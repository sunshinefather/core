package test.service;

public interface MessageService {
    String getMessage();
}
