package com.palmlink.core.search;

import java.util.List;

public class ElasticSearchSettings {
    
    private List<String> servers;

    public List<String> getServers() {
        return servers;
    }

    public void setServers(List<String> servers) {
        this.servers = servers;
    }

}