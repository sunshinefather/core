package com.palmlink.core.platform.cache;

public interface CacheKeyGenerator {
    String buildCacheKey();
}
