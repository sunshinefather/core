package com.palmlink.core.platform.scheduler;

/**
 * @author Shihai.Fu
 */
public class SchedulerException extends RuntimeException {
    public SchedulerException(Throwable cause) {
        super(cause);
    }
}
