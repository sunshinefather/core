package com.palmlink.core.collection.converter;

import java.util.Date;

import com.palmlink.core.collection.TypeConversionException;
import com.palmlink.core.util.Convert;

/**
 * Date converter
 * 
 * @author Shihai.Fu
 * 
 */
public class DateConverter {

    /**
     * convert String to Date
     * 
     * @param property
     */
    public static Date fromString(String property) {
        return parseDateTime(property);
    }

    /**
     * convert Date to String with format Convert#DATE_FORMAT_DATETIME
     * 
     * @param value
     */
    public static String toString(Date value) {
        return Convert.toString(value, Convert.DATE_FORMAT_DATETIME);
    }

    static Date parseDateTime(String textValue) {
        Date date = Convert.toDateTime(textValue, null);
        if (date == null)
            date = Convert.toDate(textValue, null);
        if (date == null)
            throw new TypeConversionException("can not convert to date, text=" + textValue);
        return date;
    }
}
