package com.palmlink.core.log;

public class LogConstants {
    public static final String MDC_REQUEST_ID = "MDC_REQUEST_ID";
    public static final String MDC_ACTION = "MDC_ACTION";
    public static final String MDC_TARGET_THREAD_ID = "MDC_TARGET_THREAD_ID";
}
