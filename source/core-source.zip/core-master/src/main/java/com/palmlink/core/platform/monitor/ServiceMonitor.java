package com.palmlink.core.platform.monitor;

/**
 * @author Shihai.Fu
 */
public interface ServiceMonitor {
    
    ServiceStatus getServiceStatus() throws Exception;

    String getServiceName();
    
}