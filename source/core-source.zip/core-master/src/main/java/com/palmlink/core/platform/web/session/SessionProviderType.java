package com.palmlink.core.platform.web.session;

public enum SessionProviderType {
    LOCAL, MEMCACHED
}
