package com.palmlink.core.platform.cache;

public enum CacheProvider {
    EHCACHE, MEMCACHED
}
