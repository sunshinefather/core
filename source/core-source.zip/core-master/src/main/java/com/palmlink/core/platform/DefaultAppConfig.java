package com.palmlink.core.platform;

import java.io.IOException;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import com.palmlink.core.http.HTTPClient;
import com.palmlink.core.platform.context.Messages;
import com.palmlink.core.platform.context.PropertyContext;
import com.palmlink.core.platform.monitor.ExceptionStatistic;
import com.palmlink.core.platform.scheduler.Scheduler;
import com.palmlink.core.platform.scheduler.SchedulerImpl;
import com.palmlink.core.platform.service.WSClientService;
import com.palmlink.core.template.FreemarkerTemplate;

public class DefaultAppConfig {

    @Bean
    public static PropertyContext propertyContext() throws IOException {
        PropertyContext propertySource = new PropertyContext();
        propertySource.setLocations(new PathMatchingResourcePatternResolver().getResources("classpath*:*.properties"));
        return propertySource;
    }

    @Bean
    public Messages messages() throws IOException {
        Resource[] messageResources = new PathMatchingResourcePatternResolver().getResources("classpath*:messages/*.properties");
        Messages messages = new Messages();
        String[] baseNames = new String[messageResources.length];
        for (int i = 0, messageResourcesLength = messageResources.length; i < messageResourcesLength; i++) {
            Resource messageResource = messageResources[i];
            String filename = messageResource.getFilename();
            baseNames[i] = "messages/" + filename.substring(0, filename.indexOf('.'));
        }
        messages.setBasenames(baseNames);
        return messages;
    }

    @Bean
    public SpringObjectFactory springObjectFactory() {
        return new SpringObjectFactory();
    }

    @Bean
    public ExceptionStatistic exceptionStatistic() {
        return new ExceptionStatistic();
    }

    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public HTTPClient httpClient() {
        return new HTTPClient();
    }

    @Bean
    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    public FreemarkerTemplate freemarkerTemplate() {
        return new FreemarkerTemplate();
    }

    @Bean
    public Scheduler scheduler() {
        return new SchedulerImpl();
    }

    @Bean
    public WSClientService wsClientService() {
        return new WSClientService();
    }

}
