package com.palmlink.core.platform.scheduler;

/**
 * @author Shihai.Fu
 */
public interface Job {
    void execute() throws Exception;
}
