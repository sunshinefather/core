package com.palmlink.core.platform.monitor;

/**
 * @author Shihai.Fu
 */
public enum ServiceStatus {
    UP, DOWN
}
