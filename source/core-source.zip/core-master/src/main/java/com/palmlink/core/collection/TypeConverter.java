package com.palmlink.core.collection;

import java.util.Date;

import org.apache.commons.lang.StringUtils;

import com.palmlink.core.collection.converter.DateConverter;
import com.palmlink.core.collection.converter.NumberConverter;

/**
 * Type convert
 * 
 * @author Shihai.Fu
 * 
 */
public class TypeConverter {

    /**
     * Convert String to specified Object
     * 
     * @param textValue
     * @param targetClass
     */
    @SuppressWarnings({ "unchecked", "rawtypes" })
    public static <T> T fromString(String textValue, Class<T> targetClass) {
        if (targetClass.isPrimitive())
            throw new IllegalArgumentException("targetClass cannot be primitive, use wrapper class instead, e.g. Integer.class for int.class");

        if (String.class.equals(targetClass))
            return (T) textValue;
        if (StringUtils.isBlank(textValue))
            return null;

        if (Boolean.class.equals(targetClass))
            return (T) Boolean.valueOf(textValue);

        if (Number.class.isAssignableFrom(targetClass))
            return (T) NumberConverter.convertToNumber(textValue, (Class<? extends Number>) targetClass);

        if (Character.class.equals(targetClass))
            return (T) Character.valueOf(textValue.charAt(0));

        if (Enum.class.isAssignableFrom(targetClass))
            return (T) Enum.valueOf((Class<Enum>) targetClass, textValue);
        if (Date.class.equals(targetClass))
            return (T) DateConverter.fromString(textValue);

        throw new TypeConversionException("not supported type, targetClass=" + targetClass.getName());
    }

    /**
     * convert Object to String
     * 
     * @param value
     * @return
     */
    @SuppressWarnings("rawtypes")
    public static String toString(Object value) {
        if (value == null)
            return "";
        if (value instanceof String)
            return (String) value;
        if (value instanceof Boolean)
            return String.valueOf(value);
        if (value instanceof Number)
            return String.valueOf(value);
        if (value instanceof Enum)
            return ((Enum) value).name();
        if (value instanceof Character)
            return String.valueOf(value);
        if (value instanceof Date)
            return DateConverter.toString((Date) value);

        throw new TypeConversionException("not supported type, targetClass=" + value.getClass().getName());
    }
}
