package com.palmlink.core.platform.permission;

public enum OperationValue {

    READ, CREATE, UPDATE, DELETE, SET, EXPORT, IMPORT, PROCESS, VERIFY;
    
}