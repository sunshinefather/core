package com.palmlink.core.mail;

/**
 * @author Shihai.Fu
 */
public class MailException extends RuntimeException {
    public MailException(Throwable cause) {
        super(cause);
    }
}
