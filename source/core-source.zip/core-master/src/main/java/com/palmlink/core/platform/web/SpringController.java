package com.palmlink.core.platform.web;

public interface SpringController {

}
